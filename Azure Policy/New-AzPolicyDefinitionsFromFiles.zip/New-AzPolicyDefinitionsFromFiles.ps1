# Set the folder path where your policy files are located
$policyFolder = "C:\Users\vterzic\OneDrive - Protera\Documents\GitHub\Protera\Azure Policy"

# Get all policy files matching your naming pattern
$policyFiles = Get-ChildItem -Path $policyFolder -Filter "AMG-Policy-DeployPrivateEndpointGroup-*.json"

foreach ($file in $policyFiles) {
    # Extract the groupId from the filename
    $groupId = $file.BaseName -replace "AMG-Policy-DeployPrivateEndpointGroup-", ""
    $policyName = "AMG-Policy-DeployPrivateEndpointGroup-$groupId"
    $displayName = "Deploy Private DNS Zone Group for $groupId"
    $description = "Deploys Private DNS Zone Group for $groupId private endpoint groupId."
    $metadata = @{ category = "_AMG" }

    # Create the policy definition
    New-AzPolicyDefinition `
        -Name $policyName `
        -DisplayName $displayName `
        -Description $description `
        -Policy $file.FullName `
        -Mode Indexed `
        -Metadata $metadata
}